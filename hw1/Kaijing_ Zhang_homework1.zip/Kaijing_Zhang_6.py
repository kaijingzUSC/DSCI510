#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def convert_distance(number):
    print("Your entered: ")
    if number < 12:
        print(str(number) + " inch")
        return
    if number >= 63360:
        quotient1 = number // 63360
        number = number % 63360
        print(str(quotient1) + " mile")
    if number >= 36:
        quotient2 = number // 36
        number = number % 36
        print(str(quotient2) + " yard")
    if number >= 12:
        quotient3 = number // 12
        number = number % 12
        print(str(quotient3) + " feet")
    if number > 0:
        print(str(number) + " inch")

