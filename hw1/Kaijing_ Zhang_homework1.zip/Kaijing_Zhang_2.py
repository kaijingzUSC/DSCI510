#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# a). Python is a dynamically typed language
# b). Values from the input() function in Python are returned as a string
# c).  The value of: True or not False and not True or False or "True" and "False" and "Frank"
# is True
# d).  Building a skeleton with stubs is an example of the top down programming paradigm
# e).  Which function tells you the type of a Python object? type()

