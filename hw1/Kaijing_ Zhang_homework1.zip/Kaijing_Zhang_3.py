#!/usr/bin/env python
# coding: utf-8

# In[ ]:


'''
Generate a random integer number "rand" between 1 and 10.
Let user guess one number "guess".
While the "guess" is not equal to "rand":
    if the "guess" is higher than "rand":
        Then tell user it's higher.
    elif the "guess" is lower than "rand":
        Then tell user it's lower.
    Let user guess one number "guess" again.
Tell user it's correct and the program terminate. 
'''

