#!/usr/bin/env python
# coding: utf-8

# In[ ]:


'''
Let user enter a number in inches marked as "number".
print("Your entered: ")
If the "number" is smaller than 12:
    print(str(number) + "inch") and stop
If the "number" can be convert to at least one mile, which means if the number is larger than 63360:
    then let the number divide by 63360 and get "quotient_1" and "remainder_1".
    print(str(quotient_1) + "mile")
If the remainder_1 can be convert to at least one yard, which means if the number is larger than 36:
    then let the number divide by 36 and get "quotient_2" and "remainder_2".
    print(str(quotient_2) + "yard")
If the remainder_2 can be convert to at least one feet, which means if the number is larger than 12:
    then let the number divide by 12 and get "quotient_3" and "remainder_3".
    print(str(quotient_3) + "feet")
If the remainder_3 is larger than zero:
    print(str(remainder_3) + "inch")
'''

