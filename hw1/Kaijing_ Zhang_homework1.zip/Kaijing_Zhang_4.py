#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def guess_number():
    import random
    rand = random.randint(1,10)
    try:
        guess = int(input("Please guess an integer between 1 and 10: "))
    except:
        guess = int(input("Please enter an !integer! between 1 and 10: "))
    while guess != rand:
        if guess > rand:
            print("Your guess is higher than the random number.")
        elif guess < rand:
            print("Your guess is lower than the random number.")
        try:
            guess = int(input("Please guess an integer between 1 and 10 again: "))
        except:
            guess = int(input("Please enter an !integer! between 1 and 10: "))
    print("Congratulations! Your guess is correct.")

