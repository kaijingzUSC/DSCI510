#!/usr/bin/env python
# coding: utf-8

# In[ ]:


ten = 1 
one = 10
zero = 1
tenplusone = "ten" + "one"

print(ten + one)
# a) Output: 11

print(ten + 1)
# b) Output: 2

print(one - 1 * zero - 0 + 10 ** ten)
# c) Output: 19

if zero - 1:
    print('ten')
# d) It will not print anything because zero - 1 is equal to 0, which means False. 

print(int(one) * 10 % 1 / int(ten) + 1 ** 10)
# e) Output: 1.0

print('tenplusone' + tenplusone + 'ten' + one)
# f) TypeError: can only concatenate str (not "int") to str. 
# Because one is an integer not an string, it can't be printed. 

