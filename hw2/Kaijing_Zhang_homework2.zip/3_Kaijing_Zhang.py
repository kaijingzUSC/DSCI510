#!/usr/bin/env python
# coding: utf-8

# In[ ]:


'''
Creat an empty list.
While True:
    Let user enter a value as input
    if input is 'done', 
        then print out the list
        break
    else 
        add the input to the list.
while True:
    Let user enter a index which must be a vaild integer, 
        which means cannot exceed the index of the list. 
    If index is vaild, 
        then print out the value in the list at the index, and break 
'''

