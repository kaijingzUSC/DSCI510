#!/usr/bin/env python
# coding: utf-8

# In[ ]:


'''
Define a function and its argument is a list input:
    Create an empty list as output
    For item in the input:
        if item is a numeric value:
            Add its absolute value to output list
        elif item is a non-numeric value but it can be converted to a numeric value:
            Convert it to a numeric value and add it to output list
    return output
'''

